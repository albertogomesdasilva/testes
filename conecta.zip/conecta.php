<?php

$serve = mysql_connect('127.0.0.1', 'root', '');
if(!$serve){ echo 'erro';}
$db = mysql_select_db('pizzas', $serve);

if($_GET['acao']=='inclusao'){

     $nome = $_GET['nome'];

     $SQL = "INSERT INTO tipos (nome) VALUES ('$nome')";

     $re = mysql_query($SQL, $serve);

}

if($_GET['acao'] == 'listapizzas'){

     $SQL = "SELECT * FROM tipos";

     $re = mysql_query($SQL, $serve);
 
     $num = mysql_num_rows($re);

     if($num > 0){
 
           while($Linha = mysql_fetch_object($re)){
                  echo "{$Linha->Nome}<br />";
           }

      }
      else{
          echo 'nenhuma pizza cadastrada';
      }
}
?>  